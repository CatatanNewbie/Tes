Powered By SundaXploit | t.me/awn_sx
VALID LOGIN KEY: SundaXploit2023

NEED REMEMBER!! this tool is only for education and I limit the users of this tool to avoid violations, that's why I locked this tool, I share it only to celebrate the 3 year anniversary of SundaXploit.

#About Tool
SundaXploit Tools is a tool that can support your needs, this tool is made from python3 with 2500+ lines of code which is then compiled. I guarantee that this tool is safe and clean, because I designed it myself. If you have questions or complaints, please contact the contact listed.

#About Shell Finder
Shell Finder is a useful tool for efficiently searching for shells by working like a dir scan. Keep in mind that this tool is still not perfect.
You can customize it in the /path directory /path/dir.txt and /path/shell.txt, keep in mind that the target list must have http/https so I recommend extracting your target list first.

#About Reverse IP
Reverse IP is the right tool for you because this tool can be used for a lifetime and it'sReverse ip adalah alat yang cocok untuk anda karena alat ini bisa digunakan secara lifetime dan gratis free.

#About Subdomain Scanner
Subdomain Scanner is a suitable tool for you because this tool can be used for a lifetime and it's free.

#About Extract Domain
Extract Domain Tool is a tool that functions to clean domains from messy text, and can remove duplicates.

#About Scanner Laravel
Laravel Scanner is a tool that can capture database accounts, smtp, and other important information, my tool is a remake from the previous tool maker named yukin0shita.

#About Grabber Domain by Date
Domain by Date Grabber is a tool capable of capturing many domains originating from the newly registered domain by date database, this tool can be used daily. I have remake from a previous maker named A.K.A.Kresna.